 component-predictive-search.css */
.predictive-search {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: rgb(var(--color-background));
  z-index: 30;
  border: 1px solid rgba(var(--color-foreground), 0.1);
  border-top: none;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-10px);
  transition: opacity 0.2s ease-in-out, transform 0.2s ease-in-out;
}

.predictive-search.is-active {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
}

.predictive-search__results {
  padding: 1rem;
}

.predictive-search__item {
  display: flex;
  align-items: center;
  padding: 0.5rem;
  cursor: pointer;
}

.predictive-search__item:hover {
  background: rgba(var(--color-foreground), 0.05);
}