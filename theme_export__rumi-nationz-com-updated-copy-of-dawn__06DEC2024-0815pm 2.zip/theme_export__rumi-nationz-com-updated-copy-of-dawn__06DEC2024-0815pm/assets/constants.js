window.theme = window.theme || {};

theme.constants = {
  mediaQueries: {
    mobile: '(max-width: 749px)',
    tabletAndUp: '(min-width: 750px)',
    desktop: '(min-width: 990px)'
  },
  keyboardKeys: {
    ENTER: 13,
    ESCAPE: 27,
    SPACE: 32,
    LEFT_ARROW: 37,
    RIGHT_ARROW: 39
  }
};
