/ global.js
window.theme = window.theme || {};

(function($) {
  const selectors = {
    drawerTrigger: '[data-drawer-trigger]',
    drawer: '[data-drawer]',
    menuMobile: '[data-menu-mobile]',
    header: '[data-header]'
  };

  class Theme {
    constructor() {
      this.init();
    }

    init() {
      this.initDrawers();
      this.initMobileMenu();
      this.initHeaderScroll();
    }

    initDrawers() {
      document.querySelectorAll(selectors.drawerTrigger).forEach(trigger => {
        trigger.addEventListener('click', this.toggleDrawer.bind(this));
      });
    }

    initMobileMenu() {
      const menuTrigger = document.querySelector(selectors.menuMobile);
      if (menuTrigger) {
        menuTrigger.addEventListener('click', this.toggleMobileMenu.bind(this));
      }
    }

    initHeaderScroll() {
      let lastScroll = 0;
      const header = document.querySelector(selectors.header);
      
      if (header) {
        window.addEventListener('scroll', () => {
          const currentScroll = window.pageYOffset;
          if (currentScroll > lastScroll && currentScroll > 100) {
            header.classList.add('is-hidden');
          } else {
            header.classList.remove('is-hidden');
          }
          lastScroll = currentScroll;
        });
      }
    }

    toggleDrawer(event) {
      const drawer = document.querySelector(
        `[data-drawer="${event.currentTarget.dataset.drawerTrigger}"]`
      );
      if (drawer) {
        drawer.classList.toggle('is-active');
      }
    }

    toggleMobileMenu() {
      document.documentElement.classList.toggle('mobile-menu-open');
    }
  }

  window.theme.Theme = Theme;
})(window.theme);