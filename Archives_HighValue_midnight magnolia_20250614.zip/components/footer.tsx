export default function Footer() {
  return (
    <footer className="bg-[#051224] py-6 border-t border-[#D4AF37]/20">
      <div className="container mx-auto px-4 text-center">
        <div className="text-xl font-bold text-[#D4AF37] mb-4">MIDNIGHT MAGNOLIA</div>
        <p className="text-[#FAF3E0] mb-4">
          Digital-first creative brand dedicated to transforming art, design, and strategy into sustainable income
          streams.
        </p>
        <div className="mt-4 text-[#FAF3E0]/60 text-sm">&copy; 2025 Midnight Magnolia | All Rights Reserved</div>
      </div>
    </footer>
  )
}

