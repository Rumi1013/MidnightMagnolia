export default function ServiceProcess() {
  const steps = [
    {
      number: 1,
      title: "Discovery Consultation",
      text: "We begin with a thorough consultation to understand your goals, challenges, and vision. This helps us tailor our approach to your specific needs.",
    },
    {
      number: 2,
      title: "Strategic Planning",
      text: "Based on our discovery findings, we create a comprehensive strategy and project plan with clear milestones, deliverables, and timelines.",
    },
    {
      number: 3,
      title: "Implementation",
      text: "Our team works diligently to bring your vision to life, with regular check-ins and updates to ensure alignment with your expectations.",
    },
    {
      number: 4,
      title: "Review & Refinement",
      text: "We collaborate with you to review the work, make any necessary adjustments, and ensure everything meets our high standards of quality.",
    },
    {
      number: 5,
      title: "Launch & Support",
      text: "We provide a smooth launch experience followed by dedicated support to ensure your continued success and satisfaction.",
    },
  ]

  return (
    <section className="py-20 bg-[#0A3B4D]">
      <div className="container mx-auto px-4">
        <h2 className="font-headers text-4xl text-[#D4AF37] mb-12 text-center pb-4 relative after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-20 after:h-0.5 after:bg-[#D4AF37]">
          Our Service Process
        </h2>

        <div className="max-w-3xl mx-auto">
          {steps.map((step) => (
            <div key={step.number} className="flex mb-12 relative">
              {step.number < steps.length && (
                <div className="absolute top-[60px] left-[25px] w-0.5 h-[calc(100%-30px)] bg-[#D4AF37]/30 md:block hidden"></div>
              )}
              <div className="w-[50px] h-[50px] bg-[#D4AF37]/30 md:block hidden"></div>
              <div className="w-[50px] h-[50px] rounded-full bg-[#D4AF37] text-[#0A192F] flex items-center justify-center font-accents font-semibold text-xl flex-shrink-0 mr-6 relative z-10">
                {step.number}
              </div>
              <div className="pt-1">
                <h3 className="font-headers text-xl text-[#D4AF37] mb-2">{step.title}</h3>
                <p className="text-[#FAF3E0]">{step.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

