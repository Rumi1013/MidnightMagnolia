export default function Logo({ width = 120, height = 120 }) {
  return (
    <svg width={width} height={height} viewBox="0 0 120 120">
      {/* Midnight Blue Background Circle */}
      <circle cx="60" cy="60" r="60" fill="#0A192F" />
      {/* Gold Crescent Moon */}
      <path
        d="M78 32C67.5 32 58.1 36.7 52 44.3C55.6 41.6 60.1 40 65 40C80.5 40 93 52.5 93 68C93 83.5 80.5 96 65 96C60.1 96 55.6 94.4 52 91.7C58.1 99.3 67.5 104 78 104C97 104 112 89 112 70C112 51 97 36 78 36V32Z"
        fill="#D4AF37"
      />
      {/* White Magnolia */}
      <circle cx="65" cy="68" r="15" fill="#FAF3E0" />
      <path d="M65 53C61 59 58 66 65 68C72 66 69 59 65 53Z" fill="#FAF3E0" />
      <path d="M65 53C69 59 72 66 65 68C58 66 61 59 65 53Z" fill="#FAF3E0" />
      <path d="M65 53C72 57 79 57 77 64C70 66 67 59 65 53Z" fill="#FAF3E0" />
      <path d="M65 53C58 57 51 57 53 64C60 66 63 59 65 53Z" fill="#FAF3E0" />
    </svg>
  )
}

