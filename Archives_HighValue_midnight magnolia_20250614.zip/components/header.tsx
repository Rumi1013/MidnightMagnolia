"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  return (
    <header className="fixed top-0 left-0 w-full bg-[#0A192F] py-4 border-b border-[#D4AF37]/20 z-50">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <div className="text-2xl font-bold text-[#D4AF37] font-['var(--font-playfair)']">MIDNIGHT MAGNOLIA</div>
        </Link>

        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            {[
              { name: "Home", path: "/" },
              { name: "Services", path: "/services" },
              { name: "Contact", path: "/contact" },
            ].map((item) => (
              <li key={item.name}>
                <Link
                  href={item.path}
                  className={`font-['var(--font-montserrat)'] text-sm font-medium
                    ${pathname === item.path ? "text-[#D4AF37]" : "text-[#FAF3E0] hover:text-[#D4AF37]"}`}
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div
          className="flex flex-col justify-between w-7 h-5 cursor-pointer md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <span className="w-full h-0.5 bg-[#D4AF37]"></span>
          <span className="w-full h-0.5 bg-[#D4AF37]"></span>
          <span className="w-full h-0.5 bg-[#D4AF37]"></span>
        </div>

        {isMenuOpen && (
          <div className="absolute top-full left-0 w-full bg-[#0A192F] py-4 md:hidden">
            {[
              { name: "Home", path: "/" },
              { name: "About", path: "/about" },
              { name: "Services", path: "/services" },
              { name: "Shop", path: "/shop" },
              { name: "Blog", path: "/blog" },
              { name: "Contact", path: "/contact" },
            ].map((item) => (
              <Link key={item.name} href={item.path} className="block py-2 px-4 text-center">
                {item.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    </header>
  )
}

