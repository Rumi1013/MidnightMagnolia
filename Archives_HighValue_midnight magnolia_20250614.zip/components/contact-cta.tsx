import Link from "next/link"

export default function ContactCTA() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=600&width=1200')] bg-cover bg-center">
        <div className="absolute inset-0 bg-[#0A192F]/80"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-headers text-4xl text-[#D4AF37] mb-6">Ready to Transform Your Vision?</h2>
          <p className="text-xl mb-10">
            Let's collaborate to create a sustainable digital presence that generates income while you sleep.
          </p>
          <Link
            href="/contact"
            className="inline-block bg-[#D4AF37] text-[#0A192F] font-accents font-semibold uppercase text-base tracking-wider py-3 px-7 rounded transition-all duration-300 hover:bg-[#BF9D30] hover:transform hover:-translate-y-0.5"
          >
            Schedule a Consultation
          </Link>
        </div>
      </div>
    </section>
  )
}

