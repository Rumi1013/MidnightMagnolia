"use client"

import { useState } from "react"

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0)

  const testimonials = [
    {
      text: "Midnight Magnolia transformed my online presence with their expert web development services. The attention to detail and technical expertise exceeded my expectations, resulting in a website that truly represents my brand while generating consistent income.",
      name: "Sarah Johnson",
      business: "Holistic Wellness Coach",
    },
    {
      text: "Working with Latisha on my brand design was an incredible experience. She has a unique ability to capture the essence of your vision and translate it into a stunning visual identity. My brand now stands out in a crowded marketplace, and I'm attracting my ideal clients.",
      name: "Marcus Taylor",
      business: "Financial Freedom Educator",
    },
    {
      text: "The strategic guidance I received from Midnight Magnolia was game-changing for my business. They helped me implement automation systems that have saved me countless hours and created new revenue streams I hadn't considered before.",
      name: "Amara Wilson",
      business: "Digital Product Creator",
    },
  ]

  const nextSlide = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevSlide = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  const goToSlide = (index: number) => {
    setActiveIndex(index)
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="font-headers text-4xl text-[#D4AF37] mb-12 text-center pb-4 relative after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-20 after:h-0.5 after:bg-[#D4AF37]">
          Client Experiences
        </h2>

        <div className="max-w-3xl mx-auto relative">
          <div className="p-6">
            <div className="bg-[#0A3B4D]/50 border border-[#D4AF37]/20 rounded-lg p-12 relative">
              <div className="absolute top-5 left-5 font-headers text-6xl text-[#D4AF37]/20 leading-none">"</div>
              <p className="font-body italic mb-6 relative z-10">{testimonials[activeIndex].text}</p>
              <div className="text-right">
                <p className="font-headers text-lg text-[#D4AF37] mb-1">{testimonials[activeIndex].name}</p>
                <p className="font-accents text-sm italic">{testimonials[activeIndex].business}</p>
              </div>
            </div>
          </div>

          <div className="flex justify-center items-center mt-6">
            <button
              onClick={prevSlide}
              className="w-9 h-9 rounded-full border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center transition-all duration-300 hover:bg-[#D4AF37] hover:text-[#0A192F]"
              aria-label="Previous testimonial"
            >
              &lt;
            </button>
            <div className="flex mx-6">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full mx-1 transition-all duration-300 ${
                    activeIndex === index ? "bg-[#D4AF37]" : "bg-[#D4AF37]/30"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            <button
              onClick={nextSlide}
              className="w-9 h-9 rounded-full border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center transition-all duration-300 hover:bg-[#D4AF37] hover:text-[#0A192F]"
              aria-label="Next testimonial"
            >
              &gt;
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

