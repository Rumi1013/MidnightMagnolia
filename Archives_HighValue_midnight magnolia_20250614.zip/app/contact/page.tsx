export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-[#D4AF37] mb-6 text-center">Contact Us</h1>

      <div className="max-w-2xl mx-auto">
        <p className="text-center mb-8">
          Ready to transform your creative vision into sustainable income streams? Let's start a conversation.
        </p>

        <form className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-[#D4AF37] mb-2">
              Name
            </label>
            <input
              type="text"
              id="name"
              className="w-full bg-[#0A192F] border border-[#D4AF37]/30 rounded p-3"
              placeholder="Your Name"
            />
          </div>

          <div>
            <label htmlFor="email" className="block text-[#D4AF37] mb-2">
              Email
            </label>
            <input
              type="email"
              id="email"
              className="w-full bg-[#0A192F] border border-[#D4AF37]/30 rounded p-3"
              placeholder="Your Email"
            />
          </div>

          <div>
            <label htmlFor="message" className="block text-[#D4AF37] mb-2">
              Message
            </label>
            <textarea
              id="message"
              rows={5}
              className="w-full bg-[#0A192F] border border-[#D4AF37]/30 rounded p-3"
              placeholder="Tell us about your project or goals"
            ></textarea>
          </div>

          <button type="submit" className="w-full bg-[#D4AF37] text-[#0A192F] py-3 px-6 rounded font-semibold">
            Send Message
          </button>
        </form>

        <div className="mt-8 text-center">
          <p>Email: hello@midnightmagnolia.com</p>
          <p>Phone: (803) 387-2552</p>
        </div>
      </div>
    </div>
  )
}

