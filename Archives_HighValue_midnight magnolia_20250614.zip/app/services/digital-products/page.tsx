import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Digital Products Service | Midnight Magnolia",
  description: "Strategically designed digital products that generate passive income and showcase your expertise.",
}

export default function DigitalProductsPage() {
  return (
    <>
      {/* Service Hero Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <div className="text-[#FAF3E0]/80 mb-4">
              <Link href="/" className="hover:text-[#D4AF37]">
                Home
              </Link>{" "}
              /
              <Link href="/services" className="mx-2 hover:text-[#D4AF37]">
                Services
              </Link>{" "}
              /<span className="text-[#D4AF37]">Digital Products</span>
            </div>
            <h1 className="text-5xl font-bold text-[#D4AF37] mb-6">Digital Product Creation</h1>
            <p className="text-xl max-w-2xl">
              Strategically designed digital products that generate passive income and showcase your expertise.
            </p>
          </div>
        </div>
      </section>

      {/* Service Overview */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-3xl text-[#D4AF37] mb-8 pb-4 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-16 after:h-0.5 after:bg-[#D4AF37]">
                Service Overview
              </h2>
              <div className="space-y-6">
                <p>
                  Our Digital Product Creation service helps you transform your knowledge and expertise into valuable
                  digital assets that generate passive income. We guide you through the entire process—from concept
                  development to launch strategy.
                </p>
                <p>
                  Whether you're creating e-books, online courses, templates, or membership sites, we ensure your
                  digital products are strategically designed to meet market demand while showcasing your unique
                  perspective and expertise.
                </p>
                <p>
                  Our approach combines market research, strategic positioning, beautiful design, and effective launch
                  strategies to maximize the success and profitability of your digital products.
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-2xl text-[#D4AF37] mb-8">Key Features</h3>
              <ul className="space-y-6">
                {[
                  {
                    title: "Product Strategy",
                    description:
                      "Market research and strategic positioning to ensure your product meets a genuine need and stands out in the marketplace.",
                  },
                  {
                    title: "Design & Development",
                    description:
                      "Professional design and development of your digital product with attention to user experience and brand consistency.",
                  },
                  {
                    title: "Content Organization",
                    description:
                      "Strategic organization and presentation of your content to maximize value and facilitate learning or implementation.",
                  },
                  {
                    title: "Launch Support",
                    description:
                      "Comprehensive launch strategy and marketing materials to ensure a successful product release.",
                  },
                ].map((feature, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#D4AF37] mr-4 mt-1">✦</div>
                    <div>
                      <h4 className="text-xl text-[#D4AF37] mb-2">{feature.title}</h4>
                      <p>{feature.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Product Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl text-[#D4AF37] mb-12 text-center section-title">Digital Product Types</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "E-Books & Guides",
                description:
                  "Beautifully designed digital publications that showcase your expertise and provide valuable information to your audience.",
                features: ["Professional Layout", "Custom Graphics", "Interactive Elements", "Multiple File Formats"],
              },
              {
                title: "Online Courses",
                description:
                  "Comprehensive learning experiences that transform your knowledge into structured educational content.",
                features: ["Curriculum Design", "Video Production", "Interactive Exercises", "Student Community"],
              },
              {
                title: "Templates & Toolkits",
                description:
                  "Ready-to-use resources that help your audience implement your methods and achieve results quickly.",
                features: [
                  "Customizable Designs",
                  "Step-by-Step Instructions",
                  "Multiple Formats",
                  "Implementation Guides",
                ],
              },
              {
                title: "Membership Sites",
                description:
                  "Recurring revenue platforms that provide ongoing value and build community around your expertise.",
                features: ["Content Strategy", "Community Features", "Tiered Access Levels", "Retention Strategies"],
              },
              {
                title: "Digital Planners",
                description:
                  "Interactive planning tools that help your audience organize, track, and achieve their goals.",
                features: ["Custom Layouts", "Hyperlinked Navigation", "Printable Options", "Branded Design"],
              },
              {
                title: "Workshops & Masterclasses",
                description: "Focused learning experiences that deliver specific outcomes and transformations.",
                features: [
                  "Curriculum Design",
                  "Presentation Materials",
                  "Workbooks & Resources",
                  "Implementation Support",
                ],
              },
            ].map((product, index) => (
              <div
                key={index}
                className="bg-[#0A192F]/50 border border-[#D4AF37]/20 rounded-lg p-8 hover:border-[#D4AF37] hover:transform hover:-translate-y-1 transition-all duration-300"
              >
                <h3 className="text-2xl text-[#D4AF37] mb-4">{product.title}</h3>
                <p className="mb-6">{product.description}</p>
                <ul className="space-y-2">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <span className="text-[#D4AF37] mr-2">✓</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl text-[#D4AF37] mb-12 text-center section-title">Investment</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                title: "Product Strategy",
                price: "$1,500+",
                features: [
                  "Market Research",
                  "Product Positioning",
                  "Audience Analysis",
                  "Pricing Strategy",
                  "Launch Plan Outline",
                ],
              },
              {
                title: "Product Development",
                price: "$3,500+",
                features: [
                  "Content Organization",
                  "Professional Design",
                  "Custom Graphics",
                  "User Experience Optimization",
                  "Technical Implementation",
                  "Quality Assurance",
                ],
                featured: true,
              },
              {
                title: "Complete Package",
                price: "$6,500+",
                features: [
                  "Strategy & Development",
                  "Sales Page Creation",
                  "Marketing Materials",
                  "Launch Support",
                  "Post-Launch Analysis",
                  "30-Day Support",
                ],
              },
            ].map((plan, index) => (
              <div
                key={index}
                className={`border rounded-lg overflow-hidden ${
                  plan.featured ? "border-[#D4AF37] bg-[#0A192F]/70 relative" : "border-[#D4AF37]/20 bg-[#0A192F]/30"
                }`}
              >
                {plan.featured && (
                  <div className="absolute top-4 right-4">
                    <span className="bg-[#D4AF37] text-[#0A192F] text-xs font-semibold uppercase py-1 px-3 rounded-full">
                      Popular
                    </span>
                  </div>
                )}
                <div className="p-8">
                  <h3 className="text-2xl text-[#D4AF37] mb-2">{plan.title}</h3>
                  <div className="text-2xl font-semibold text-[#D4AF37] mb-6">{plan.price}</div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <span className="text-[#D4AF37] mr-2">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/contact"
                    className={`block text-center font-semibold uppercase text-sm py-3 px-6 rounded ${
                      plan.featured
                        ? "bg-[#D4AF37] text-[#0A192F] hover:bg-[#BF9D30]"
                        : "border-2 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10"
                    }`}
                  >
                    Get Started
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center mt-8 text-[#FAF3E0]/80 max-w-2xl mx-auto">
            Pricing varies based on the complexity and scope of your digital product. Contact us for a personalized
            quote tailored to your specific project.
          </p>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-4xl text-[#D4AF37] mb-6">Ready to Create Your Digital Product?</h2>
            <p className="text-xl mb-8">
              Let's transform your expertise into valuable digital assets that generate passive income while you sleep.
            </p>
            <Link href="/contact" className="btn-primary">
              Schedule a Consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

