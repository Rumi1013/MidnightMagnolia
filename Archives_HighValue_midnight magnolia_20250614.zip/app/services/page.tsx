import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Services | Midnight Magnolia",
  description: "Digital-first solutions to transform your creative vision into sustainable income streams",
}

export default function ServicesPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold text-[#D4AF37] mb-6">Services</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Digital-first solutions to transform your creative vision into sustainable income streams
          </p>
        </div>
      </section>

      {/* Services Introduction */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl text-[#D4AF37] mb-8 section-title">Expert Services for Digital Entrepreneurs</h2>
            <p className="text-lg mb-4">
              At Midnight Magnolia, we offer a range of specialized services designed to help you build a sustainable
              digital presence and create multiple income streams. Our solutions combine technical expertise with
              creative vision, all wrapped in our distinctive Southern Gothic Digital aesthetic.
            </p>
            <p className="text-lg">
              Each service is tailored to meet your specific needs and goals, with a focus on implementation,
              automation, and long-term growth.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {/* Category Tabs */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {["All Services", "Web Development", "Brand Design", "Digital Products", "Business Strategy"].map(
              (category, index) => (
                <button
                  key={category}
                  className={`px-5 py-2.5 border rounded ${
                    index === 0
                      ? "bg-[#D4AF37] text-[#0A192F] border-[#D4AF37]"
                      : "bg-transparent text-[#FAF3E0] border-[#D4AF37]/30 hover:bg-[#D4AF37] hover:text-[#0A192F]"
                  }`}
                >
                  {category}
                </button>
              ),
            )}
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                id: "web-development",
                title: "Custom Web Development",
                description:
                  "Bespoke websites built with advanced HTML, CSS, and JavaScript to create a unique digital presence.",
                features: ["Responsive Design", "Custom Animations", "SEO Optimization"],
                category: "web",
              },
              {
                id: "brand-design",
                title: "Brand Identity Design",
                description:
                  "Comprehensive brand identity systems that communicate your unique value and attract your ideal clients.",
                features: ["Logo Design", "Color Palette", "Typography System"],
                category: "design",
              },
              {
                id: "digital-products",
                title: "Digital Product Creation",
                description:
                  "Strategically designed digital products that generate passive income and showcase your expertise.",
                features: ["Product Strategy", "Design & Development", "Launch Support"],
                category: "digital",
              },
              {
                id: "business-strategy",
                title: "Business Automation",
                description:
                  "Systems and workflows that streamline your operations and free up your time for creative work.",
                features: ["Workflow Optimization", "Tool Integration", "Process Documentation"],
                category: "strategy",
              },
              {
                id: "content-strategy",
                title: "Content Strategy",
                description:
                  "Strategic content planning that builds authority and drives consistent traffic to your digital platforms.",
                features: ["Content Calendar", "SEO Research", "Distribution Plan"],
                category: "strategy",
              },
              {
                id: "ecommerce",
                title: "E-commerce Solutions",
                description:
                  "Custom online stores that showcase your products and provide a seamless shopping experience.",
                features: ["Product Showcase", "Secure Checkout", "Inventory Management"],
                category: "web",
              },
            ].map((service) => (
              <div
                key={service.id}
                className="bg-[#0A192F]/50 border border-[#D4AF37]/20 rounded-lg overflow-hidden hover:border-[#D4AF37] hover:transform hover:-translate-y-1 transition-all duration-300"
              >
                <div className="h-48 bg-[#0A3B4D] flex items-center justify-center border-b-2 border-[#D4AF37]/30">
                  <div className="text-[#D4AF37] text-6xl opacity-30">✦</div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl text-[#D4AF37] mb-3">{service.title}</h3>
                  <p className="mb-6">{service.description}</p>
                  <ul className="mb-6 space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center">
                        <span className="text-[#D4AF37] mr-2">✦</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    href={`/services/${service.id}`}
                    className="inline-block text-[#D4AF37] font-semibold uppercase text-sm tracking-wider hover:underline"
                  >
                    Learn More
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl text-[#D4AF37] mb-12 text-center section-title">Our Service Process</h2>

          <div className="max-w-3xl mx-auto">
            {[
              {
                number: 1,
                title: "Discovery Consultation",
                text: "We begin with a thorough consultation to understand your goals, challenges, and vision. This helps us tailor our approach to your specific needs.",
              },
              {
                number: 2,
                title: "Strategic Planning",
                text: "Based on our discovery findings, we create a comprehensive strategy and project plan with clear milestones, deliverables, and timelines.",
              },
              {
                number: 3,
                title: "Implementation",
                text: "Our team works diligently to bring your vision to life, with regular check-ins and updates to ensure alignment with your expectations.",
              },
              {
                number: 4,
                title: "Review & Refinement",
                text: "We collaborate with you to review the work, make any necessary adjustments, and ensure everything meets our high standards of quality.",
              },
              {
                number: 5,
                title: "Launch & Support",
                text: "We provide a smooth launch experience followed by dedicated support to ensure your continued success and satisfaction.",
              },
            ].map((step) => (
              <div key={step.number} className="flex mb-12">
                <div className="w-[50px] h-[50px] rounded-full bg-[#D4AF37] text-[#0A192F] flex items-center justify-center font-bold text-xl flex-shrink-0 mr-6">
                  {step.number}
                </div>
                <div>
                  <h3 className="text-xl text-[#D4AF37] mb-2">{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl text-[#D4AF37] mb-12 text-center section-title">Client Experiences</h2>

          <div className="max-w-3xl mx-auto">
            <div className="bg-[#0A3B4D]/50 border border-[#D4AF37]/20 rounded-lg p-8 relative">
              <div className="absolute top-5 left-5 text-6xl text-[#D4AF37]/20 leading-none">"</div>
              <p className="italic mb-6 relative z-10">
                Midnight Magnolia transformed my online presence with their expert web development services. The
                attention to detail and technical expertise exceeded my expectations, resulting in a website that truly
                represents my brand while generating consistent income.
              </p>
              <div className="text-right">
                <p className="text-lg text-[#D4AF37] mb-1">Sarah Johnson</p>
                <p className="text-sm italic">Holistic Wellness Coach</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-4xl text-[#D4AF37] mb-6">Ready to Transform Your Vision?</h2>
            <p className="text-xl mb-8">
              Let's collaborate to create a sustainable digital presence that generates income while you sleep.
            </p>
            <Link href="/contact" className="btn-primary">
              Schedule a Consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

