import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Web Development Service | Midnight Magnolia",
  description:
    "Bespoke websites built with advanced HTML, CSS, and JavaScript to create a unique digital presence that reflects your brand identity.",
}

export default function WebDevelopmentPage() {
  return (
    <>
      {/* Service Hero Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <div className="text-[#FAF3E0]/80 mb-4">
              <Link href="/" className="hover:text-[#D4AF37]">
                Home
              </Link>{" "}
              /
              <Link href="/services" className="mx-2 hover:text-[#D4AF37]">
                Services
              </Link>{" "}
              /<span className="text-[#D4AF37]">Web Development</span>
            </div>
            <h1 className="text-5xl font-bold text-[#D4AF37] mb-6">Custom Web Development</h1>
            <p className="text-xl max-w-2xl">
              Bespoke websites built with advanced HTML, CSS, and JavaScript to create a unique digital presence that
              reflects your brand identity.
            </p>
          </div>
        </div>
      </section>

      {/* Service Overview */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-3xl text-[#D4AF37] mb-8 pb-4 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-16 after:h-0.5 after:bg-[#D4AF37]">
                Service Overview
              </h2>
              <div className="space-y-6">
                <p>
                  Our Custom Web Development service is designed for businesses and entrepreneurs who want a distinctive
                  online presence that stands out from template-based websites. We combine technical expertise with
                  creative vision to build websites that not only look beautiful but also function flawlessly.
                </p>
                <p>
                  Every project begins with a deep dive into your brand, goals, and target audience. We then craft a
                  custom design and development plan that addresses your specific needs while incorporating our
                  signature Southern Gothic Digital aesthetic.
                </p>
                <p>
                  Our development process emphasizes clean, semantic code, responsive design, and user experience best
                  practices to ensure your website performs beautifully across all devices and platforms.
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-2xl text-[#D4AF37] mb-8">Key Features</h3>
              <ul className="space-y-6">
                {[
                  {
                    title: "Responsive Design",
                    description:
                      "Your website will look and function perfectly on all devices, from desktops to smartphones.",
                  },
                  {
                    title: "Custom Animations",
                    description:
                      "Subtle, elegant animations that enhance user experience without sacrificing performance.",
                  },
                  {
                    title: "SEO Optimization",
                    description:
                      "Built-in search engine optimization to help your site rank higher and attract more visitors.",
                  },
                  {
                    title: "Third-Party Integrations",
                    description:
                      "Seamless integration with payment processors, email marketing tools, and other services.",
                  },
                ].map((feature, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#D4AF37] mr-4 mt-1">✦</div>
                    <div>
                      <h4 className="text-xl text-[#D4AF37] mb-2">{feature.title}</h4>
                      <p>{feature.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl text-[#D4AF37] mb-12 text-center section-title">Investment</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                title: "Basic Website",
                price: "$3,500+",
                features: [
                  "5-7 Custom Pages",
                  "Responsive Design",
                  "Basic SEO Setup",
                  "Contact Form",
                  "Content Management System",
                ],
              },
              {
                title: "Business Website",
                price: "$5,500+",
                features: [
                  "8-12 Custom Pages",
                  "Advanced Animations",
                  "Comprehensive SEO",
                  "Email Marketing Integration",
                  "Blog/News Section",
                  "Social Media Integration",
                ],
                featured: true,
              },
              {
                title: "E-commerce Website",
                price: "$8,500+",
                features: [
                  "Custom Product Pages",
                  "Secure Payment Processing",
                  "Inventory Management",
                  "Customer Accounts",
                  "Order Tracking",
                  "Marketing Integrations",
                ],
              },
            ].map((plan, index) => (
              <div
                key={index}
                className={`border rounded-lg overflow-hidden ${
                  plan.featured ? "border-[#D4AF37] bg-[#0A192F]/70 relative" : "border-[#D4AF37]/20 bg-[#0A192F]/30"
                }`}
              >
                {plan.featured && (
                  <div className="absolute top-4 right-4">
                    <span className="bg-[#D4AF37] text-[#0A192F] text-xs font-semibold uppercase py-1 px-3 rounded-full">
                      Popular
                    </span>
                  </div>
                )}
                <div className="p-8">
                  <h3 className="text-2xl text-[#D4AF37] mb-2">{plan.title}</h3>
                  <div className="text-2xl font-semibold text-[#D4AF37] mb-6">{plan.price}</div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <span className="text-[#D4AF37] mr-2">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/contact"
                    className={`block text-center font-semibold uppercase text-sm py-3 px-6 rounded ${
                      plan.featured
                        ? "bg-[#D4AF37] text-[#0A192F] hover:bg-[#BF9D30]"
                        : "border-2 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10"
                    }`}
                  >
                    Get Started
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center mt-8 text-[#FAF3E0]/80 max-w-2xl mx-auto">
            All packages are customizable based on your specific needs. Contact us for a personalized quote tailored to
            your project requirements.
          </p>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-[#0A3B4D]">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-4xl text-[#D4AF37] mb-6">Ready to Transform Your Vision?</h2>
            <p className="text-xl mb-8">
              Let's collaborate to create a sustainable digital presence that generates income while you sleep.
            </p>
            <Link href="/contact" className="btn-primary">
              Schedule a Consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}

