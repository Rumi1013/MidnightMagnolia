import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Business Strategy Service | Midnight Magnolia",
  description: "Systems and workflows that streamline your operations and free up your time for creative work.",
}

export default function BusinessStrategyPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/services" className="text-[#D4AF37]">
          ← Back to Services
        </Link>
      </div>

      <h1 className="text-4xl font-bold text-[#D4AF37] mb-6">Business Automation</h1>

      <p className="mb-6">
        Systems and workflows that streamline your operations and free up your time for creative work.
      </p>

      <div className="bg-[#0A3B4D] p-6 rounded-lg mb-8">
        <h2 className="text-2xl text-[#D4AF37] mb-4">Service Overview</h2>
        <p className="mb-4">
          Our Business Automation service helps creative entrepreneurs and small businesses streamline their operations
          through strategic systems and workflows. We identify opportunities for automation and implement solutions that
          save time, reduce errors, and create consistency.
        </p>
      </div>

      <h2 className="text-2xl text-[#D4AF37] mb-4">Areas We Can Automate</h2>
      <ul className="mb-8 space-y-2">
        <li>• Client Management - Streamline client onboarding and communication</li>
        <li>• Content Creation - Systematize your content creation process</li>
        <li>• Email Marketing - Create automated email sequences</li>
        <li>• Financial Management - Automate invoicing and expense tracking</li>
      </ul>

      <div className="text-center mt-8">
        <Link href="/contact" className="inline-block bg-[#D4AF37] text-[#0A192F] px-6 py-3 rounded font-semibold">
          Schedule a Consultation
        </Link>
      </div>
    </div>
  )
}

