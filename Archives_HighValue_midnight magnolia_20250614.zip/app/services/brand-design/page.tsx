import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Brand Design Service | Midnight Magnolia",
  description:
    "Comprehensive brand identity systems that communicate your unique value and attract your ideal clients.",
}

export default function BrandDesignPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/services" className="text-[#D4AF37]">
          ← Back to Services
        </Link>
      </div>

      <h1 className="text-4xl font-bold text-[#D4AF37] mb-6">Brand Identity Design</h1>

      <p className="mb-6">
        Comprehensive brand identity systems that communicate your unique value and attract your ideal clients.
      </p>

      <div className="bg-[#0A3B4D] p-6 rounded-lg mb-8">
        <h2 className="text-2xl text-[#D4AF37] mb-4">Service Overview</h2>
        <p className="mb-4">
          Our Brand Identity Design service creates cohesive visual systems that authentically represent your business
          and resonate with your ideal audience. We go beyond just creating a logo—we develop a comprehensive brand
          identity that tells your story across all touchpoints.
        </p>
      </div>

      <h2 className="text-2xl text-[#D4AF37] mb-4">Key Features</h2>
      <ul className="mb-8 space-y-2">
        <li>• Logo Design - Primary and secondary logo variations</li>
        <li>• Color Palette - Strategic color selection</li>
        <li>• Typography System - Carefully selected font pairings</li>
        <li>• Brand Guidelines - Comprehensive documentation</li>
      </ul>

      <div className="text-center mt-8">
        <Link href="/contact" className="inline-block bg-[#D4AF37] text-[#0A192F] px-6 py-3 rounded font-semibold">
          Schedule a Consultation
        </Link>
      </div>
    </div>
  )
}

